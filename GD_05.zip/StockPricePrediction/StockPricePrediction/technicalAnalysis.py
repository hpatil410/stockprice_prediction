import yfinance as yf
import numpy as np
import  pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error
import seaborn as sns # Visualization
sns.set_style('white', { 'axes.spines.right': False, 'axes.spines.top': False})
from keras.models import load_model
from datetime import date, timedelta

'''stock = input("Enter the name of Stock")

sdate = input("Enter the Start date(YYYY-MM-DD)")

edate = input("Enter the End date(YYYY-MM-DD)")

df = yf.download(stock,sdate,edate)
df.reset_index(level=0, inplace=True)'''


#Trend Indicator

from ta.trend import SMAIndicator
from ta.trend import EMAIndicator
from ta.trend import ADXIndicator
from ta.trend import IchimokuIndicator
from ta.trend import MACD

#Momentum Indicator
from ta.momentum import RSIIndicator
from ta.momentum import ROCIndicator
from ta.momentum import AwesomeOscillatorIndicator
from ta.momentum import KAMAIndicator
from ta.momentum import PercentagePriceOscillator
from ta.momentum import PercentageVolumeOscillator
from ta.momentum import StochRSIIndicator
from ta.momentum import StochasticOscillator
from ta.momentum import WilliamsRIndicator
from ta.momentum import TSIIndicator

#volatility Indicator
from ta.volatility import AverageTrueRange
from ta.volatility import BollingerBands
from ta.volume import AccDistIndexIndicator




def create_csv(df):
    indicator_sma = SMAIndicator(df['Close'],14,False)
    indicator_ema = EMAIndicator(df['Close'],14,False)
    indicator_adx = ADXIndicator(df['High'],df['Low'],df['Close'],14,False)

    indicator_RSIIndicator = RSIIndicator(df['Close'],14,False)
    indicator_ROCIndicator = ROCIndicator(df['Close'],14,False)
    indicator_AwesomeOscillatorIndicator = AwesomeOscillatorIndicator(df['High'],df['Low'],5,34,False)
    indicator_KAMAIndicator = KAMAIndicator(df['Close'], 10,2,30,False)
    indicator_PercentagePriceOscillator = PercentagePriceOscillator(df['Close'],26,12,9,False)
    indicator_PercentageVolumeOscillator = PercentageVolumeOscillator(df['Volume'], 26,12,9,False)
    indicator_StochRSIIndicator = StochRSIIndicator(df['Close'],14,3,3,False)
    indicator_StochasticOscillator = StochasticOscillator(df['High'],df['Low'],df['Close'],14,3,False)
    indicator_WilliamsRIndicator = WilliamsRIndicator( df['High'],df['Low'],df['Close'],14,False )
    indicator_TSIIndicator = TSIIndicator(df['Close'],25,13,False)

    indicator_atr = AverageTrueRange(df['High'],df['Low'],df['Close'],14,False)
    indicator_adindex = AccDistIndexIndicator(df['High'],df['Low'],df['Close'],df['Volume'])
    indicator_bollinger = BollingerBands(df['Close'],14,2,False)


    df['SMA']= indicator_sma.sma_indicator()
    df['EMA']= indicator_ema.ema_indicator()
    df['ADX']= indicator_adx.adx()


    df['RSI']= indicator_RSIIndicator.rsi()
    df['ROC'] = indicator_ROCIndicator.roc()
    df['AwesomeOscillatorIndicator'] = indicator_AwesomeOscillatorIndicator.awesome_oscillator()
    df['KAMAIndicator'] = indicator_KAMAIndicator.kama()
    df['PercentagePriceOscillator'] = indicator_PercentagePriceOscillator.ppo()
    df['PercentageVolumeOscillator'] = indicator_PercentageVolumeOscillator.pvo()
    df['StochRSIIndicator'] = indicator_StochRSIIndicator.stochrsi()
    df['StochasticOscillator'] = indicator_StochasticOscillator.stoch()
    df['WilliamsRIndicator'] = indicator_WilliamsRIndicator.williams_r()
    df['TSIIndicator'] = indicator_TSIIndicator.tsi()


    df['ATR'] = indicator_atr.average_true_range()
    df['AD_Index'] = indicator_adindex.acc_dist_index()
    df['Bollinger-Band'] = indicator_bollinger.bollinger_pband()

    print(df.head())


    import pandas as pd

    df.to_csv('technical_analysis.csv')

def train_model(stock,sdate,edate):
    stockname = stock
    start_date = sdate
    end_date = edate
    train = pd.read_csv('technical_analysis.csv',parse_dates=['Date'],index_col='Date')
    train = train.dropna()
    train = train.drop("Unnamed: 0",axis=1)
    print(train.head())
    print(train.tail())
    train.isnull().sum()/len(train)*100
    train.corr()['Close']
    train.var()

    #LOW VARIANCE FILTER
    numeric = train[['High','Low','Close','Open','Volume','SMA','EMA','ADX','RSI','ROC','AwesomeOscillatorIndicator','KAMAIndicator','PercentagePriceOscillator','PercentageVolumeOscillator','StochRSIIndicator','StochasticOscillator','WilliamsRIndicator', 'TSIIndicator','ATR','AD_Index','Bollinger-Band']]
    var = numeric.var()
    numeric = numeric.columns
    variable_1 = [ ]
    for i in range(0,len(var)):
        if var[i]>=50:   #setting the threshold as 10%
           variable_1.append(numeric[i+1])

    print(variable_1)

    #HIGH VARIANCE FILTER
    final = train.drop(['High','Low','Open','Adj Close'],axis=1)
    final.corr()

    #Random Forest for feature selection
    from sklearn.ensemble import RandomForestRegressor
    model = RandomForestRegressor(random_state=1, max_depth=10)
    final=pd.get_dummies(final)
    model.fit(final,train.Close)

    import matplotlib.pyplot as plt
    features = final.columns
    importances = model.feature_importances_
    indices = np.argsort(importances)[-9:]  # top 10 features
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.yticks(range(len(indices)), [features[i] for i in indices])
    plt.xlabel('Relative Importance')
    plt.savefig('features.jpg')
    plt.clf()

    #Forward Selection
    from sklearn.feature_selection import f_regression
    ffs = f_regression(final,train.Close )
    variable_2 = [ ]
    for i in range(0,len(final.columns)-1):
        if ffs[0][i] >=10:
           variable_2.append(final.columns[i])
    print(variable_2)

    #SelctKBest Features
    from sklearn.feature_selection import SelectKBest, f_regression, chi2

    bestfeatures = SelectKBest(score_func=f_regression, k='all')
    fit = bestfeatures.fit(final,train.Close)

    dfscores = pd.DataFrame(fit.scores_)
    dfcolumns = pd.DataFrame(final.columns)

    featureScores = pd.concat([dfcolumns,dfscores],axis=1)
    featureScores.columns = ['Specs','Score']  #naming the dataframe columns

    print(featureScores.nlargest(5,'Score'))  #print 5 best features


    print(final.head(3))

    #MODEL
    from keras.models import Sequential, load_model
    from keras.layers.core import Dense
    from keras.layers import LSTM
    from keras import optimizers
    from keras.callbacks import EarlyStopping
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import mean_squared_error, r2_score
    from math import sqrt
    import datetime as dt
    import time


    # Extracting the series
    data_filtered = train[['Close','SMA','EMA','KAMAIndicator','ATR','AD_Index']] # Picking the series with high correlation
    print(data_filtered.shape)
    print("SERIES tail",data_filtered.tail())
    print("SERIES head",data_filtered.head())

    data_filtered_ext = data_filtered.copy()
    data_filtered_ext['Prediction'] = data_filtered_ext['Close']

    print('Series ext', data_filtered_ext.tail())

    nrows = data_filtered.shape[0]

    # Convert the data to numpy values
    np_data_unscaled = np.array(data_filtered)
    np_data = np.reshape(np_data_unscaled, (nrows, -1))
    print("np data shape", np_data.shape)

    # Transform the data by scaling each feature to a range between 0 and 1
    scaler = MinMaxScaler()
    np_data_scaled = scaler.fit_transform(np_data_unscaled)

    # Creating a separate scaler that works on a single column for scaling predictions
    scaler_pred = MinMaxScaler()
    df_Close = pd.DataFrame(data_filtered_ext['Close'])
    np_Close_scaled = scaler_pred.fit_transform(df_Close)

    # Set the sequence length - this is the timeframe used to make a single prediction
    sequence_length = 50

    # Prediction Index
    index_Close = train.columns.get_loc("Close")

    import math
    # Split the training data into train and train data sets
    # As a first step, we get the number of rows to train the model on 80% of the data
    train_data_len = math.ceil(np_data_scaled.shape[0] * 0.8)

    # Create the training and test data
    train_data = np_data_scaled[0:train_data_len, :]
    test_data = np_data_scaled[train_data_len - sequence_length:, :]

    # The RNN needs data with the format of [samples, time steps, features]
    # Here, we create N samples, sequence_length time steps per sample, and 6 features
    def partition_dataset(sequence_length, data):
        x, y = [], []
        data_len = data.shape[0]
        for i in range(sequence_length, data_len):
            x.append(data[i - sequence_length:i, :])  # contains sequence_length values 0-sequence_length * columsn
            y.append(data[i, index_Close])  # contains the prediction values for validation,  for single-step prediction

        # Convert the x and y to numpy arrays
        x = np.array(x)
        y = np.array(y)
        return x, y

    # Generate training data and test data
    x_train, y_train = partition_dataset(sequence_length, train_data)
    x_test, y_test = partition_dataset(sequence_length, test_data)

    # Print the shapes: the result is: (rows, training_sequence, features) (prediction value, )
    print(x_train.shape, y_train.shape)
    print(x_test.shape, y_test.shape)

    # Validate that the prediction value and the input match up
    # The last close price of the second input sample should equal the first prediction value
    print(x_train[1][sequence_length - 1][index_Close])
    print(y_train[0])

    # Configure the neural network model
    model = Sequential()

    # Model with n_neurons = inputshape Timestamps, each with x_train.shape[2] variables
    n_neurons = x_train.shape[1] * x_train.shape[2]
    print(n_neurons, x_train.shape[1], x_train.shape[2])
    model.add(LSTM(n_neurons, return_sequences=True, input_shape=(x_train.shape[1], x_train.shape[2])))
    model.add(LSTM(n_neurons, return_sequences=False))
    model.add(Dense(5))
    model.add(Dense(1))

    # Compile the model
    model.compile(optimizer='adam', loss='mse')

    # Training the model
    epochs = 1
    batch_size = 24
    early_stop = EarlyStopping(monitor='loss', patience=5, verbose=1)
    history = model.fit(x_train, y_train,
                        batch_size=batch_size,
                        epochs=epochs,
                        validation_data=(x_test, y_test)
                        )

    # callbacks=[early_stop])

    # Get the predicted values
    y_pred_scaled = model.predict(x_test)

    # Unscale the predicted values
    y_pred = scaler_pred.inverse_transform(y_pred_scaled)
    y_test_unscaled = scaler_pred.inverse_transform(y_test.reshape(-1, 1))


    # Mean Absolute Error (MAE)
    MAE = mean_absolute_error(y_test, y_pred_scaled)
    print(f'Median Absolute Error (MAE): {np.round(MAE, 2)}')

    MSE = mean_squared_error(y_test, y_pred_scaled)
    print(f'Mean Squared Error (MSE): {np.round(MSE, 2)}')

    RMSE = math.sqrt(MSE)
    print(f'Root Mean Squared Error (RMSE): {np.round(RMSE, 2)}')

    R2_SCORE = r2_score(y_test_unscaled, y_pred)
    print(f'R2 Score: {np.round(R2_SCORE, 2)}')

    # Mean Absolute Percentage Error (MAPE)
    MAPE = np.mean((np.abs(np.subtract(y_test_unscaled, y_pred) / y_test_unscaled))) * 100
    print(f'Mean Absolute Percentage Error (MAPE): {np.round(MAPE, 2)} %')

    # Median Absolute Percentage Error (MDAPE)
    MDAPE = np.median((np.abs(np.subtract(y_test_unscaled, y_pred) / y_test_unscaled))) * 100
    print(f'Median Absolute Percentage Error (MDAPE): {np.round(MDAPE, 2)} %')

    # The date from which on the date is displayed
    display_start_date = "2019-01-01"

    # Add the difference between the valid and predicted prices
    train = pd.DataFrame(data_filtered_ext['Close'][:train_data_len + 1]).rename(columns={'Close': 'y_train'})
    valid = pd.DataFrame(data_filtered_ext['Close'][train_data_len:]).rename(columns={'Close': 'y_test'})
    valid.insert(1, "y_pred", y_pred, True)
    valid.insert(1, "residuals", valid["y_pred"] - valid["y_test"], True)
    df_union = pd.concat([train, valid])

    # Zoom in to a closer timeframe
    df_union_zoom = df_union[df_union.index > display_start_date]

    # Create the lineplot
    fig, ax1 = plt.subplots(figsize=(16, 8))
    plt.title("y_pred vs y_test")
    plt.ylabel(stockname, fontsize=18)
    sns.set_palette(["#090364", "#1960EF", "#EF5919"])
    sns.lineplot(data=df_union_zoom[['y_pred', 'y_train', 'y_test']], linewidth=1.0, dashes=False, ax=ax1)

    # Create the bar plot with the differences
    df_sub = ["#2BC97A" if x > 0 else "#C92B2B" for x in df_union_zoom["residuals"].dropna()]
    ax1.bar(height=df_union_zoom['residuals'].dropna(), x=df_union_zoom['residuals'].dropna().index, width=3,
            label='residuals', color=df_sub)
    plt.legend()
    fname = 'static/images/stockimage.jpg'
    plt.savefig(fname)
    plt.clf()
    #plt.show()

    temp_df = data_filtered
    new_df = temp_df[-sequence_length:]
    print("new df", new_df)
    #new_df = df_temp.filter(FEATURES)

    N = sequence_length

    # Get the last N day closing price values and scale the data to be values between 0 and 1
    last_N_days = data_filtered[-sequence_length:].values
    last_N_days_scaled = scaler.transform(last_N_days)

    # Create an empty list and Append past N days
    X_test_new = []
    X_test_new.append(last_N_days_scaled)

    # Convert the X_test data set to a numpy array and reshape the data
    pred_price_scaled = model.predict(np.array(X_test_new))
    pred_price_unscaled = scaler_pred.inverse_transform(pred_price_scaled.reshape(-1, 1))

    # Print last price and predicted price for the next day
    price_today = np.round(new_df['Close'][-1], 2)
    predicted_price = np.round(pred_price_unscaled.ravel()[0], 2)
    change_percent = np.round(100 - (price_today * 100) / predicted_price, 2)

    plus = '+';
    minus = ''
    print(f'The close price for {stockname} at {end_date} was {price_today}')
    print(f'The predicted close price is {predicted_price} ({plus if change_percent > 0 else minus}{change_percent}%)')

    return  MAE,MAPE,MDAPE,MSE,RMSE,R2_SCORE,price_today,predicted_price


