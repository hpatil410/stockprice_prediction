# line plot of time series
from pandas import read_csv
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
import numpy
import pandas as pd


# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return numpy.array(diff)

# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]

def futurePrediction(DATASET):
	# load dataset
	series = read_csv(DATASET, header=0, index_col=0)
	# display first few rows
	print(series.head(20))
	# seasonal difference
	X = series.values
	print(X)
	total_years = len(series)-2
	differenced = difference(X, total_years)
	# fit model
	model = ARIMA(differenced, order=(7,0,1))
	model_fit = model.fit()

	# print summary of fit model
	print(model_fit.summary())

	# multi-step out-of-sample forecast

	start_index = len(differenced)
	end_index = start_index + 6
	forecast = model_fit.predict(start=start_index, end=end_index)
	print(forecast)

	history = [x for x in X]
	predictedFuture = []
	day = 1
	for yhat in forecast:
		inverted = inverse_difference(history, yhat, total_years)
		print('Day %d: %f' % (day, inverted))
		history.append(inverted)
		predictedFuture.append(inverted)
		day += 1

	return(predictedFuture)










