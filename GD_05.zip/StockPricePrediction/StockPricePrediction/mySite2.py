# import the necessary packages
from flask import Flask, render_template, redirect, url_for, request,session,Response
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.tsa.arima_model import ARIMA
import yfinance as yf 
import nltk
from arima_model import *
from technicalAnalysis import *

app = Flask(__name__)

app.secret_key = '1234'
app.config["CACHE_TYPE"] = "null"
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

@app.route('/', methods=['GET', 'POST'])
def homepage():
	return render_template('home.html')

@app.route('/home', methods=['GET', 'POST'])
def home():
	return render_template('home.html')

@app.route('/info', methods=['GET', 'POST'])
def info():
	return render_template('info.html')

@app.route('/input', methods=['GET', 'POST'])
def input():
	if request.method == 'POST':
		
		stock = request.form['stock']
		sdate = request.form['sdate']
		edate = request.form['edate']

		data = yf.download(stock,sdate,edate)
		stockPrice = data['Adj Close']
		print(stockPrice)
		stockPrice.to_csv('historic_data.csv')
		data['Adj Close'].plot()
		plt.savefig('static/images/stockprice.jpg')
		plt.clf()

		predictedFuture = futurePrediction('historic_data.csv')
		#print(predictedFuture)
		pf = []
		for val in predictedFuture:
			pf.append(val[0])
		#print(pf)
		day = ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Day 7"]
		newdf = pd.DataFrame(list(zip(day,pf)))
		newdf.columns = ['Day','Price']
		print(newdf)
		return render_template('input.html',tables=[newdf.to_html(classes='w3-table-all w3-hoverable')], titles=newdf.columns.values)

	return render_template('input.html')


@app.route('/lstm', methods=['GET', 'POST'])
def lstm():
	if request.method == 'POST':
		stock = request.form['stock']
		sdate = request.form['sdate']
		edate = request.form['edate']

		df = yf.download(stock, sdate, edate)
		df.reset_index(level=0, inplace=True)
		create_csv(df)
		mae,mape,mdape,mse,rmse,r2_score,price_today,predicted_price = train_model(stock,sdate,edate)
		#predictFuture = future_predict()
		#newdf = pd.DataFrame(predictFuture)
		#print(newdf)
		return render_template('lstm.html',mae = mae, mape = mape, mdape=mdape, mse=mse, rmse=rmse, r2_score=r2_score,price_today=price_today, predicted_price = predicted_price)
	return render_template('lstm.html')

# No caching at all for API endpoints.
@app.after_request
def add_header(response):
	# response.cache_control.no_store = True
	response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
	response.headers['Pragma'] = 'no-cache'
	response.headers['Expires'] = '-1'
	return response


if __name__ == '__main__':
	app.run(host='0.0.0.0', debug=False, threaded=True)